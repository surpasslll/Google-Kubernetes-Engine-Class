/**********************************************************************
 * file:  sr_router.c
 * date:  Mon Feb 18 12:50:42 PST 2002
 * Contact: casado@stanford.edu
 *
 * Description:
 *
 * This file contains all the functions that interact directly
 * with the routing table, as well as the main entry method
 * for routing.
 *
 **********************************************************************/

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <stdbool.h>


#include "sr_if.h"
#include "sr_rt.h"
#include "sr_router.h"
#include "sr_protocol.h"
#include "sr_arpcache.h"
#include "sr_utils.h"

struct sr_rt* longest_match(struct sr_instance*, uint32_t);
/*---------------------------------------------------------------------
 * Method: sr_init(void)
 * Scope:  Global
 *
 * Initialize the routing subsystem
 *
 *---------------------------------------------------------------------*/

void sr_init(struct sr_instance* sr)
{
    /* REQUIRES */
    assert(sr);

    /* Initialize cache and cache cleanup thread */
    sr_arpcache_init(&(sr->cache));

    pthread_attr_init(&(sr->attr));
    pthread_attr_setdetachstate(&(sr->attr), PTHREAD_CREATE_JOINABLE);
    pthread_attr_setscope(&(sr->attr), PTHREAD_SCOPE_SYSTEM);
    pthread_attr_setscope(&(sr->attr), PTHREAD_SCOPE_SYSTEM);
    pthread_t thread;

    pthread_create(&thread, &(sr->attr), sr_arpcache_timeout, sr);
    
    /* Add initialization code here! */

} /* -- sr_init -- */

/*---------------------------------------------------------------------
 * Method: sr_handlepacket(uint8_t* p,char* interface)
 * Scope:  Global
 *
 * This method is called each time the router receives a packet on the
 * interface.  The packet buffer, the packet length and the receiving
 * interface are passed in as parameters. The packet is complete with
 * ethernet headers.
 *
 * Note: Both the packet buffer and the character's memory are handled
 * by sr_vns_comm.c that means do NOT delete either.  Make a copy of the
 * packet instead if you intend to keep it around beyond the scope of
 * the method call.
 *
 *---------------------------------------------------------------------*/

void sr_handlepacket(struct sr_instance* sr,
        uint8_t * packet/* lent */,
        unsigned int len,
        char* interface/* lent */)
{
  /* REQUIRES */
  assert(sr);
  assert(packet);
  assert(interface);

  printf("*** -> Received packet of length %d \n",len);

  /* fill in code here */
  if(sanityCheck(packet,len)!=1){
	  /*failed sanity check*/
	  return;
  }
  struct sr_if* myinterface = sr_get_interface(sr,interface);
  sr_ethernet_hdr_t* raw_ethframe = (sr_ethernet_hdr_t*) packet;
  if(raw_ethframe->ether_type==htons(ethertype_ip)){
		fprintf(stdout, "INSIDE IP\n");
	  handle_ip(sr, (sr_ip_hdr_t*) (packet+sizeof(sr_ethernet_hdr_t)), len-sizeof(sr_ethernet_hdr_t),myinterface,raw_ethframe);
  }
  else if(raw_ethframe->ether_type==htons(ethertype_arp)){
		fprintf(stdout, "INSIDE ARP\n");

	  handle_arp(sr,(sr_arp_hdr_t*) (packet+sizeof(sr_ethernet_hdr_t)), len-sizeof(sr_ethernet_hdr_t),myinterface);
  }
}

int sanityCheck(uint8_t* packet, uint32_t len){
	if(len<sizeof(sr_ethernet_hdr_t)){
		return 0;
	}
	uint32_t min_size = sizeof(sr_ethernet_hdr_t);

	sr_ethernet_hdr_t* my_header = (sr_ethernet_hdr_t*) packet;
	switch(ethertype(packet)){
	case ethertype_ip :
			min_size+=sizeof(sr_ip_hdr_t);
			if(len<min_size){
				return 0;
			}
			sr_ip_hdr_t* ip_header = (sr_ip_hdr_t*) (packet + sizeof(sr_ethernet_hdr_t));
			if (cksum(ip_header, sizeof(sr_ip_hdr_t)) != 0xFFFF) {
				return 0;
			}
			if (ip_header->ip_p == ip_protocol_icmp) { /* ICMP */
				min_size += sizeof(sr_icmp_hdr_t);
				if (len < min_size) {
					return 0;
				}
				sr_icmp_hdr_t *icmp_hdr = (sr_icmp_hdr_t *)(packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
				if (cksum(icmp_hdr, len - sizeof(sr_ethernet_hdr_t) - sizeof(sr_ip_hdr_t)) != 0xFFFF) {
					return 0;
				}

			}
			break;
	case ethertype_arp :
			min_size += sizeof(sr_arp_hdr_t);
			if (len < min_size) {
				return 0;
			}
			break;
	default:
			return 0;
	}
	return 1;
}



void handle_arp(struct sr_instance* sr, sr_arp_hdr_t* packet, int len, struct sr_if* interface){
	uint16_t optype = ntohs(packet->ar_op);
	if(optype == arp_op_request){
		if(packet->ar_tip == interface->ip){
			fprintf(stdout,"MAKING ARP REPLY\n");
			uint8_t* myreply = (uint8_t*) malloc(sizeof(sr_ethernet_hdr_t) + sizeof(sr_arp_hdr_t));
			sr_ethernet_hdr_t* ether_header = (sr_ethernet_hdr_t*) myreply;
			sr_arp_hdr_t* arp_header = (sr_arp_hdr_t*)(myreply + sizeof(sr_ethernet_hdr_t));
			arp_header->ar_hrd = htons(arp_hrd_ethernet);
			arp_header->ar_pln = sizeof(uint32_t);
			arp_header->ar_pro = htons(ethertype_ip);
			arp_header->ar_op = htons(arp_op_reply);
			arp_header->ar_hln = ETHER_ADDR_LEN;


			/*switch sender and target addresses in reply packet*/
			memcpy(arp_header->ar_sha, interface->addr, ETHER_ADDR_LEN);
			memcpy(arp_header->ar_tha, packet->ar_sha, ETHER_ADDR_LEN);
			arp_header->ar_sip = interface->ip;
            arp_header->ar_tip = packet->ar_sip;

            memcpy(ether_header->ether_dhost, packet->ar_sha, ETHER_ADDR_LEN);
            memcpy(ether_header->ether_shost, interface->addr, ETHER_ADDR_LEN);
            ether_header->ether_type = htons(ethertype_arp);
            unsigned int length_reply = sizeof(sr_ethernet_hdr_t)+sizeof(sr_arp_hdr_t);
            sr_send_packet(sr,myreply,length_reply,interface->name);
            fprintf(stdout,"SENT ARP REPLY\n");

            free(myreply);

		}

	}
	else if(optype==arp_op_reply){
		if(packet->ar_tip == interface->ip){
			fprintf(stdout,"RECEIVED AN ARP REPLY\n");
			struct sr_arpreq* ptr = sr_arpcache_insert(&sr->cache, packet->ar_sha, ntohl(packet->ar_sip));
			if(ptr == NULL){
				/*no request*/
			}
			else{
				fprintf(stdout,"SENDING PACKETS THAT WERE IN QUEUE\n");
				while(ptr->packets != NULL){
					struct sr_packet* currReq = ptr->packets;
					memcpy(((sr_ethernet_hdr_t*) currReq->buf)->ether_dhost, packet->ar_sha, ETHER_ADDR_LEN);

                    sr_send_packet(sr, currReq->buf, currReq->len, currReq->iface);
					ptr->packets = ptr->packets->next;
					free(currReq->buf);
                    free(currReq->iface);
                    free(currReq);
				}
	            sr_arpreq_destroy(&sr->cache, ptr);

			}
		}
	}
}

void handle_ip(struct sr_instance* sr, sr_ip_hdr_t* packet, int len, struct sr_if* interface, sr_ethernet_hdr_t* eth_hdr){
	if(selfDestination(sr,packet)){
		/*packet destined toward us*/
		if(packet->ip_p == (uint8_t) ip_protocol_icmp){
			/*handle icmp packet*/
			fprintf(stdout, "FOR MEEEE IPP\n");
			print_hdr_ip((uint8_t*)packet);
			handleICMPPacket(sr,packet,len,eth_hdr->ether_shost,eth_hdr->ether_dhost);
		}
		else{
			/*send icmp dest port unreachable*/
			fprintf(stdout,"SHOULDNT BE HERE\n");
			configureICMPThree(sr,packet, 3, eth_hdr->ether_shost);
		}
	}
	else{
		/*forward packet */
		uint8_t ttlCount = packet->ip_ttl -1;
		if(ttlCount==0){
			/*drop packet, send icmp message*/
			configureICMPEleven(sr,packet,eth_hdr->ether_shost);
			return;
		}
		packet->ip_ttl = ttlCount;
		packet->ip_sum=0;
		packet->ip_sum = cksum(packet,sizeof(sr_ip_hdr_t));
		struct sr_rt* forwardDest = longest_match(sr,packet->ip_dst);
		fprintf(stdout,"LONGEST MATCH FOUND\n");
		if(forwardDest==NULL){
			/*Send ICMP dest host unreachable*/
			fprintf(stdout,"SENDING ICMPTHREEEE HOST UNRECHALE\n");
			configureICMPThree(sr,packet,0,eth_hdr->ether_shost);
		}
		else{
			uint8_t* forwarder = malloc(len+sizeof(sr_ethernet_hdr_t));
			memcpy(forwarder + sizeof(sr_ethernet_hdr_t),packet,len);
			fprintf(stdout,"ABOUT TO CONSULT ARP TABLE\n");
			consultARPTable(sr,(sr_ethernet_hdr_t*)forwarder,len+sizeof(sr_ethernet_hdr_t),forwardDest);
			free(forwarder);
		}
	}

}

void handleICMPPacket(struct sr_instance* sr, sr_ip_hdr_t* packet, int len, uint8_t dmacaddr[ETHER_ADDR_LEN], uint8_t smacaddr[ETHER_ADDR_LEN]){
	sr_icmp_hdr_t* icmp_pac = (sr_icmp_hdr_t*) (((uint8_t*) packet) + sizeof(sr_ip_hdr_t));
	int icmpLength = len - sizeof(sr_ip_hdr_t);
	if(icmp_pac->icmp_type==8){
		uint8_t* echoreply = (uint8_t*) malloc(len+sizeof(sr_ethernet_hdr_t));
		sr_ip_hdr_t* reply_ip = (sr_ip_hdr_t*) (echoreply+sizeof(sr_ethernet_hdr_t));
		memcpy((uint8_t*)reply_ip,(uint8_t*)packet,len);
		sr_icmp_hdr_t* reply_icmp = (sr_icmp_hdr_t*) ((uint8_t*) reply_ip + sizeof(sr_ip_hdr_t));
		reply_ip->ip_v = 4;
		reply_ip->ip_p = ip_protocol_icmp;
		reply_ip->ip_hl = 5;
		reply_ip->ip_off = htons(IP_DF);
		reply_ip->ip_tos = 0;
		reply_ip->ip_id=0;
		reply_ip->ip_len = packet->ip_len;
		reply_ip->ip_ttl = 255;
		reply_ip->ip_src = packet->ip_dst;
		reply_ip->ip_dst = packet->ip_src;
		reply_ip->ip_sum = 0;
		reply_ip->ip_sum = cksum(reply_ip, sizeof(sr_ip_hdr_t));


		reply_icmp->icmp_type=0;
		reply_icmp->icmp_code=0;
		reply_icmp->icmp_sum=0;
		reply_icmp->icmp_sum=cksum(reply_icmp,icmpLength);

		struct sr_rt* table = longest_match(sr,packet->ip_src);
		consultARPTable(sr,(sr_ethernet_hdr_t*)echoreply,len+sizeof(sr_ethernet_hdr_t),table);

		fprintf(stdout,"SENT ECHO REPLY\n");
		free(echoreply);
	}
}

void configureICMPEleven(struct sr_instance* sr, sr_ip_hdr_t* ip_packet, uint8_t macaddr[ETHER_ADDR_LEN]){
	uint8_t* reply = malloc(sizeof(sr_ethernet_hdr_t)+sizeof(sr_ip_hdr_t)+sizeof(sr_icmp_t3_hdr_t));
	sr_ip_hdr_t* reply_ip = (sr_ip_hdr_t*) (reply+sizeof(sr_ethernet_hdr_t));
	sr_icmp_t3_hdr_t* reply_icmp = (sr_icmp_t3_hdr_t*) (reply+sizeof(sr_ethernet_hdr_t)+sizeof(sr_ip_hdr_t));
	reply_ip->ip_hl=5;
	reply_ip->ip_len=htons(sizeof(sr_ip_hdr_t) + sizeof(sr_icmp_t3_hdr_t));
	reply_ip->ip_tos=0;
	reply_ip->ip_v=4;
	reply_ip->ip_id=htons(ip_packet->ip_id)+1;
	reply_ip->ip_ttl=64;
	reply_ip->ip_off=htons(IP_DF);
	reply_ip->ip_p=ip_protocol_icmp;
	reply_ip->ip_dst=ip_packet->ip_src;
	struct sr_rt* table = longest_match(sr,ip_packet->ip_src);
	struct sr_if* interface = sr_get_interface(sr,table->interface);
	reply_ip->ip_src=interface->ip;
	reply_ip->ip_sum=0;
	reply_ip->ip_sum=cksum(reply_ip,sizeof(sr_ip_hdr_t));

	reply_icmp->icmp_type = 11;
	reply_icmp->icmp_code = 0;
	reply_icmp->icmp_sum = 0;
	memcpy(reply_icmp->data, ip_packet, ICMP_DATA_SIZE);
	reply_icmp->icmp_sum = cksum(reply_icmp, sizeof(sr_icmp_t3_hdr_t));

	sr_ethernet_hdr_t* eth_reply = (sr_ethernet_hdr_t*) reply;
	memcpy(eth_reply->ether_dhost, macaddr, ETHER_ADDR_LEN);
	memcpy(eth_reply->ether_shost, interface->addr, ETHER_ADDR_LEN);
	eth_reply->ether_type = htons(ethertype_ip);

	uint32_t len = sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t) + sizeof(sr_icmp_t3_hdr_t);
	uint8_t* buf = malloc(len);
	memcpy(buf, eth_reply, sizeof(sr_ethernet_hdr_t));
	memcpy(buf + sizeof(sr_ethernet_hdr_t), reply_ip, sizeof(sr_ip_hdr_t));
	memcpy(buf + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t), reply_icmp, sizeof(sr_icmp_t3_hdr_t));

	/*send icmp type 11*/
	sr_send_packet(sr,buf,len,table->interface);
	fprintf(stdout,"CREATED TYPE 11 ICMP ERROR\n");


	free(buf);
	free(reply);

}

void configureICMPThree(struct sr_instance* sr, sr_ip_hdr_t* ip_packet, uint8_t code, uint8_t macaddr[ETHER_ADDR_LEN]){
	uint8_t* reply = malloc(sizeof(sr_ethernet_hdr_t)+sizeof(sr_ip_hdr_t)+sizeof(sr_icmp_t3_hdr_t));
	sr_ip_hdr_t* reply_ip = (sr_ip_hdr_t*) (reply+sizeof(sr_ethernet_hdr_t));
	sr_icmp_t3_hdr_t* reply_icmp = (sr_icmp_t3_hdr_t*) (reply+sizeof(sr_ethernet_hdr_t)+sizeof(sr_ip_hdr_t));

	reply_ip->ip_hl=5;
	reply_ip->ip_len=htons(sizeof(sr_ip_hdr_t) + sizeof(sr_icmp_t3_hdr_t));
	reply_ip->ip_tos=0;
	reply_ip->ip_v=4;
	reply_ip->ip_id=htons(ip_packet->ip_id)+1;
	reply_ip->ip_off=htons(IP_DF);
	reply_ip->ip_ttl=64;
	reply_ip->ip_p=ip_protocol_icmp;
	reply_ip->ip_dst=ip_packet->ip_src;
	struct sr_rt* table = longest_match(sr,ip_packet->ip_src);
	struct sr_if* interface = sr_get_interface(sr,table->interface);
	reply_ip->ip_src=interface->ip;
	reply_ip->ip_sum=0;
	reply_ip->ip_sum=cksum(reply_ip,sizeof(sr_ip_hdr_t));

	reply_icmp->icmp_type=3;
	reply_icmp->icmp_code=code;
	memcpy(reply_icmp->data, ip_packet, ICMP_DATA_SIZE);
	reply_icmp->icmp_sum=0;
	reply_icmp->icmp_sum = cksum(reply_icmp,sizeof(sr_icmp_t3_hdr_t));

	sr_ethernet_hdr_t* eth_reply = (sr_ethernet_hdr_t*) reply;
	memcpy(eth_reply->ether_dhost, macaddr, ETHER_ADDR_LEN);
	memcpy(eth_reply->ether_shost, interface->addr, ETHER_ADDR_LEN);
	eth_reply->ether_type = htons(ethertype_ip);

	uint32_t len = sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t) + sizeof(sr_icmp_t3_hdr_t);
	uint8_t* buf = malloc(len);
	memcpy(buf, eth_reply, sizeof(sr_ethernet_hdr_t));
	memcpy(buf + sizeof(sr_ethernet_hdr_t), reply_ip, sizeof(sr_ip_hdr_t));
	memcpy(buf + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t), reply_icmp, sizeof(sr_icmp_t3_hdr_t));

	/*send icmp type 3*/
	sr_send_packet(sr,buf,len,table->interface);
	fprintf(stdout,"CREATED TYPE 3 ICMP ERROR\n");

	free(buf);
	free(reply);

}


struct sr_rt* longest_match(struct sr_instance* router, uint32_t ip){

	struct in_addr addr;
	addr.s_addr = ip;
	struct sr_rt* entry;
	struct sr_rt* match=NULL;
	int maxl = 0;
	for (entry = router->routing_table; entry != NULL; entry = entry->next) {
		if (((entry->dest.s_addr & entry->mask.s_addr) == (addr.s_addr & entry->mask.s_addr)) && (maxl <= entry->mask.s_addr)) {
			match = entry;
			maxl = entry->mask.s_addr;
		}
	}
	return match;
}

void consultARPTable(struct sr_instance* sr, sr_ethernet_hdr_t* packet, int len, struct sr_rt* route){
	uint32_t nextHopIP = ntohl(route->gw.s_addr);
	fprintf(stdout,"NEXT HOPPPPP\n");
	struct sr_arpentry* entry = sr_arpcache_lookup(&sr->cache, nextHopIP);
	packet->ether_type = htons(ethertype_ip);
	memcpy(packet->ether_shost,sr_get_interface(sr,route->interface)->addr,ETHER_ADDR_LEN);
	if(entry==NULL){
		/*arp request to next hop*/
		fprintf(stdout,"BOUT TO PUT REQueST ON Que\n");
		struct sr_arpreq* arpReq = sr_arpcache_queuereq(&sr->cache, nextHopIP, (uint8_t*) packet,len,route->interface);

		sr_arpcache_handle(sr,arpReq);
	}
	else {
		memcpy(packet->ether_dhost,entry->mac,ETHER_ADDR_LEN);
		fprintf(stdout,"Found arp in cache\n");
		sr_send_packet(sr,(uint8_t*) packet, len, route->interface);
		fprintf(stdout,"FOUND ARP IN CACHE, SENT\n");
		free(entry);
	}
}

void configureARPReq(struct sr_instance* sr, uint32_t dest, struct sr_rt* table){

	fprintf(stdout,"WORKEDDDDD\n");
	struct sr_if* interface;
	interface = sr_get_interface(sr, table->interface);

	sr_ethernet_hdr_t *eth_pac;
	eth_pac = (sr_ethernet_hdr_t*) malloc(sizeof(sr_ethernet_hdr_t));
	memcpy(eth_pac->ether_shost, interface->addr, ETHER_ADDR_LEN);
	memset(eth_pac->ether_dhost, 255, ETHER_ADDR_LEN);
	eth_pac->ether_type = htons(ethertype_arp);

		sr_arp_hdr_t *arp_pac;
		arp_pac = (sr_arp_hdr_t*) malloc(sizeof(sr_arp_hdr_t));
		arp_pac->ar_hrd = htons(arp_hrd_ethernet);
		arp_pac->ar_sip = interface->ip;
		arp_pac->ar_tip = dest;
		arp_pac->ar_pro = htons(ethertype_ip);
		arp_pac->ar_op = htons(arp_op_request);
		arp_pac->ar_hln = ETHER_ADDR_LEN;
		arp_pac->ar_pln = sizeof(uint32_t);
		memset(arp_pac->ar_tha, 255, ETHER_ADDR_LEN);
		memcpy(arp_pac->ar_sha, interface->addr, ETHER_ADDR_LEN);



		uint32_t len = sizeof(sr_ethernet_hdr_t) + sizeof(sr_arp_hdr_t);
		uint8_t* buf = malloc(len);
		memcpy(buf, eth_pac, sizeof(sr_ethernet_hdr_t));
		memcpy(buf + sizeof(sr_ethernet_hdr_t), arp_pac, sizeof(sr_arp_hdr_t));

		sr_send_packet(sr,buf,len,table->interface);


		free(arp_pac);
		free(eth_pac);
		free(buf);
}

int selfDestination(struct sr_instance* sr, sr_ip_hdr_t* packet){
	struct sr_if* interface;
	for(interface = sr->if_list; interface!=NULL; interface=interface->next){
			if(packet->ip_dst == interface->ip){
				return 1;
			}
	}
	return 0;
}
